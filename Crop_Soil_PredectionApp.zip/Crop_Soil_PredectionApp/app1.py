import streamlit as st
st.set_page_config(page_title="Crop Requirements Predictor", layout="centered")

import pandas as pd
from sklearn.preprocessing import LabelEncoder
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_absolute_error

# Load and preprocess data
@st.cache_data
def load_and_prepare_data():
    df = pd.read_csv('data_core.csv')

    le_crop = LabelEncoder()
    le_soil = LabelEncoder()
    le_fert = LabelEncoder()

    df['Crop Type'] = le_crop.fit_transform(df['Crop Type'])
    df['Soil Type'] = le_soil.fit_transform(df['Soil Type'])
    df['Fertilizer Name'] = le_fert.fit_transform(df['Fertilizer Name'])

    X = df[['Crop Type']]
    y = df.drop(columns=['Crop Type'])

    return df, X, y, le_crop, le_soil, le_fert

# Load data and encoders
df, X, y, le_crop, le_soil, le_fert = load_and_prepare_data()

# Split and train the model
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
model = RandomForestRegressor(n_estimators=100, random_state=42)
model.fit(X_train, y_train)

# Evaluate model
y_pred = model.predict(X_test)
mae = mean_absolute_error(y_test, y_pred)

# -------------------- Streamlit Interface --------------------

st.title("🌿 Crop Requirements Predictor")
st.markdown("Predict ideal **soil and environmental** conditions for a selected crop.")
st.markdown(f"**Model Accuracy (Mean Absolute Error):** `{mae:.2f}`")

# Dropdown to choose crop
crop_name = st.selectbox("Select a Crop Type:", le_crop.classes_)

# Predict button
if st.button("Predict Requirements"):
    try:
        crop_encoded = le_crop.transform([crop_name])
        prediction = model.predict([[crop_encoded[0]]])[0]

        result = {
            "🌡️ Temperature (°C)": round(prediction[0], 2),
            "💧 Humidity (%)": round(prediction[1], 2),
            "🪴 Moisture (%)": round(prediction[2], 2),
            "🧪 Soil Type": le_soil.inverse_transform([int(round(prediction[3]))])[0],
            "🔋 Nitrogen (N)": int(round(prediction[4])),
            "🧬 Phosphorus (P)": int(round(prediction[5])),
            "⚗️ Potassium (K)": int(round(prediction[6])),
            "🧫 Recommended Fertilizer": le_fert.inverse_transform([int(round(prediction[7]))])[0],
        }

        st.success(f"Recommended Growing Conditions for **{crop_name}**")
        for key, value in result.items():
            st.write(f"{key}: **{value}**")

    except Exception as e:
        st.error(f"❌ Prediction failed: {e}")
